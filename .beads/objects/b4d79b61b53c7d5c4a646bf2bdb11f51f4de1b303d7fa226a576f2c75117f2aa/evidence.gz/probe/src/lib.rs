//! Exact observation-source compile probe; no native cross-target runtime claim.
pub mod config { pub mod observation; }
