//! Native effects for the shared MCK engine. The engine remains the checker.
mod client;
mod fixture;
mod measurements;

use std::{
    collections::BTreeMap,
    path::Path,
    sync::{Arc, atomic::AtomicBool},
};

use cap_std::fs::Dir;
use morphir_common::config::observation::ReadLimits;
use morphir_devkit::ConfigLoadOptions;
use morphir_mck::{
    transport::Limits,
    workbench::model_originals::native::{
        CaptureScope, NativeAdapterError, NativeAuthentication, NativeOriginalAction,
        NativeOriginalAdapter, NativeOriginalMeasurements, NativeOriginalRun, NativeReadTarget,
        SemanticRequest, data,
    },
};
use serde_json::{Value, json};
use sha2::{Digest as _, Sha256};

use super::{
    model_originals::{
        CaptureId,
        observation::{
            HostObservationLimits, HostSourceObservationScope, HostSourceSnapshot,
            WorkerObservationLimits,
        },
    },
    native_startup::PreparedNativeUi,
    prepare_native_ui_observed,
    provider::WorkspaceCapability as _,
    server::BoundUiHost,
};
use client::{Deadline, RunningHost};
use measurements::{SnapshotPhase, Witnesses, alias, data_error, text};

pub(in crate::commands) struct NativeWorkbenchAdapter {
    limits: Limits,
    interrupted: Arc<AtomicBool>,
}
impl NativeWorkbenchAdapter {
    /// Construction performs no filesystem, host or transport effects.
    pub(in crate::commands) fn new(limits: Limits, interrupted: Arc<AtomicBool>) -> Self {
        Self {
            limits,
            interrupted,
        }
    }
}
impl NativeOriginalAdapter for NativeWorkbenchAdapter {
    fn observe(
        &mut self,
        run: NativeOriginalRun<'_>,
    ) -> Result<NativeOriginalMeasurements, NativeAdapterError> {
        // The command calls the shared synchronous engine inside block_in_place.
        // Reuse that actual runtime, never a second synthetic service worker.
        let runtime =
            tokio::runtime::Handle::try_current().map_err(|_| NativeAdapterError::Startup)?;
        runtime.block_on(observe(run, self.limits, self.interrupted.clone()))
    }
}

enum ProductState {
    Empty,
    Ready,
    Released,
    Closed,
}
#[derive(Clone, Copy)]
enum CaptureWork {
    NotRequested,
    Requested,
}

async fn observe(
    mut run: NativeOriginalRun<'_>,
    limits: Limits,
    interrupted: Arc<AtomicBool>,
) -> Result<NativeOriginalMeasurements, NativeAdapterError> {
    let deadline = Deadline::new(limits, interrupted)?;
    deadline.check()?;
    let fixture = fixture::Fixture::materialize(&mut run, || deadline.check())?;
    deadline.check()?;
    let held = Dir::open_ambient_dir(&fixture.root, cap_std::ambient_authority())
        .map_err(|_| NativeAdapterError::Startup)?;
    let policy = run.observation_limits();
    let scope = HostSourceObservationScope::bind_native_ui(
        &held,
        &fixture.root,
        ReadLimits::new(
            policy.source_attempts(),
            policy.source_read_calls(),
            policy.source_returned_bytes(),
            policy.source_files(),
        )
        .map_err(|_| NativeAdapterError::Startup)?,
        WorkerObservationLimits::new(policy.worker_attempts(), policy.worker_updates())
            .map_err(|_| NativeAdapterError::Startup)?,
        HostObservationLimits::new(policy.host_updates())
            .map_err(|_| NativeAdapterError::Startup)?,
    )
    .map_err(|_| NativeAdapterError::Startup)?;
    let witnesses = run.source().witnesses();
    let register = |path: &str| -> Result<_, NativeAdapterError> {
        Ok((
            path.to_owned(),
            scope
                .source_scope()
                .register_file(&held, Path::new(path))
                .map_err(|_| NativeAdapterError::Startup)?,
        ))
    };
    let files = Witnesses {
        record: register(witnesses.compile_record())?,
        primary: register(witnesses.original_primary())?,
        sentinel: register(witnesses.undeclared_sentinel())?,
    };
    let session = uuid::Uuid::new_v4().to_string();
    let home = crate::home::MorphirHome::resolve().map_err(|_| NativeAdapterError::Startup)?;
    let prepared = prepare_native_ui_observed(
        held,
        &fixture.root,
        &session,
        home,
        ConfigLoadOptions::default(),
        fixture.output.clone(),
        &scope,
    )
    .map_err(|_| NativeAdapterError::Startup)?;
    let sources = prepared.workspace_provider().initial_sources();
    let source = sources.first().ok_or(NativeAdapterError::Discovery)?;
    if sources.len() != 1 {
        return Err(NativeAdapterError::UnsupportedAction);
    }
    let source_wire = json!({"providerId":source.provider_id,"locator":source.locator});
    let source_data = data::SourceIdentity {
        provider: data::ProviderId::new(&source.provider_id)
            .map_err(|_| NativeAdapterError::Discovery)?,
        locator: data::SourceLocator::new(&source.locator)
            .map_err(|_| NativeAdapterError::Discovery)?,
    };
    let (host, records) = BoundUiHost::bind_record_observed(
        session.clone(),
        prepared.capabilities(),
        Some(prepared.originals_provider()),
        &scope,
    )
    .await
    .map_err(|_| NativeAdapterError::Startup)?;
    let usage = host.model_originals_observer();
    // This alias names this one genuine bound registration for comparison DATA;
    // it grants neither a provider nor permission to select another host.
    let registration = alias(&format!("registration-{}", uuid::Uuid::new_v4()))?;
    let mut host = RunningHost::start(host);
    let mut prepared = Some(prepared);
    let mut scope = Some(scope);
    let mut final_snapshot = None;
    let mut connection = None;
    let mut provider_alias = None;
    let mut project_alias = None;
    let mut capture_alias = None;
    let mut capture_id: Option<CaptureId> = None;
    let mut actual_project = None;
    let mut state = ProductState::Empty;
    let mut capture_work = CaptureWork::NotRequested;
    let mut transcript = Vec::new();
    let mut captures = Vec::new();
    let mut checkpoints = Vec::new();
    let mut entries = BTreeMap::new();
    let mut record_observer = None;
    let mut private_record = None;
    let mut ready_reply = None;
    let mut final_checkpoint = None;
    let mut disposed_transports = 0;

    let result: Result<(), NativeAdapterError> = async {
        for action in run.actions() {
            deadline.check()?;
            match action {
                NativeOriginalAction::Connect { authentication, connection: selected } => {
                    if authentication != NativeAuthentication::Valid || connection.is_some() {
                        return Err(NativeAdapterError::UnsupportedAction);
                    }
                    host.connect(&deadline).await?;
                    let (initialized, _) = host.request(&deadline, u64::MAX,
                        "morphir.session.initialize", json!({"protocolVersion":1,"sessionId":session})).await?;
                    if initialized["result"]["protocolVersion"] != 1 { return Err(NativeAdapterError::Authentication); }
                    connection = Some(selected.clone());
                }
                NativeOriginalAction::Discover { connection: selected, provider } => {
                    require_alias(connection.as_ref(), selected)?;
                    let fixture = run.fixture();
                    let declared = fixture.providers().find(|p| p.alias() == provider).ok_or(NativeAdapterError::Selection)?;
                    if declared.locator() != source.locator { return Err(NativeAdapterError::Selection); }
                    let (opened, _) = host.request(&deadline, u64::MAX - 1, "morphir.workspace.open", json!({"source":source_wire})).await?;
                    if !opened["result"]["snapshot"]["projects"].is_array() { return Err(NativeAdapterError::Discovery); }
                    provider_alias = Some(provider.clone());
                    ready_reply = Some(opened);
                }
                NativeOriginalAction::CaptureSelected { capture, connection: selected, project, provider,
                    request_id, scope: requested_scope, semantic, .. } => {
                    require_alias(connection.as_ref(), selected)?;
                    require_alias(provider_alias.as_ref(), provider)?;
                    if semantic != SemanticRequest::None { return Err(NativeAdapterError::UnsupportedAction); }
                    let fixture = run.fixture();
                    let declared = fixture.providers().find(|p| p.alias() == provider).ok_or(NativeAdapterError::Selection)?;
                    let binding = declared.projects().find(|p| p.alias() == project).ok_or(NativeAdapterError::Selection)?;
                    let discovered = ready_reply.as_ref().ok_or(NativeAdapterError::Discovery)?["result"]["snapshot"]["projects"]
                        .as_array().ok_or(NativeAdapterError::Discovery)?;
                    let actual = discovered.iter().find(|p| p["relativePath"].as_str() == Some(binding.module()))
                        .ok_or(NativeAdapterError::Selection)?;
                    let project_id = text(actual, "id")?.to_owned();
                    capture_work = CaptureWork::Requested;
                    let (reply, frames) = host.request(&deadline, request_id, "morphir.model-originals.capture", json!({
                        "contractVersion":"0.1.0-draft.1", "source":source_wire,"projectId":project_id,
                        "scope":match requested_scope { CaptureScope::Primary=>"primary",CaptureScope::Complete=>"complete" },
                        "semantic":"none",
                    })).await?;
                    let ready = &reply["result"];
                    captures.push(measurements::capture(ready, capture)?);
                    let id = CaptureId::parse(text(ready, "captureId")?).map_err(|_| NativeAdapterError::Exchange)?;
                    record_observer = Some(records.for_capture(&id).map_err(|_| NativeAdapterError::ObservationIncomplete)?);
                    capture_id = Some(id);
                    capture_alias = Some(capture.clone());
                    project_alias = Some(project.clone());
                    actual_project = Some(project_id);
                    ready_reply = Some(reply);
                    transcript.push(frames);
                    state = ProductState::Ready;
                }
                NativeOriginalAction::Checkpoint { name } => {
                    let snapshot = match final_snapshot.as_ref() {
                        Some(snapshot) => snapshot,
                        None => &scope.as_ref().ok_or(NativeAdapterError::Cleanup)?.snapshot(),
                    };
                    let selected = connection.as_ref().ok_or(NativeAdapterError::Selection)?;
                    let capture = capture_alias.as_ref().ok_or(NativeAdapterError::Selection)?;
                    let state_data = match state {
                        ProductState::Ready => data::CaptureState::Ready { capture:capture.clone(), connection:selected.clone() },
                        ProductState::Released => data::CaptureState::Released { last_capture:capture.clone(), connection:selected.clone() },
                        ProductState::Closed => data::CaptureState::Closed { cleanup:data::CaptureStateClosedCleanup::None{} },
                        ProductState::Empty => return Err(NativeAdapterError::Selection),
                    };
                    let retained = record_observer.as_ref().map_or(0, |observer| observer.snapshot().retained_bytes());
                    let phase = match final_snapshot { Some(_) => SnapshotPhase::Sealed, None => SnapshotPhase::Open };
                    checkpoints.push(data::NativeCheckpoint {
                        name:name.clone(), connection:selected.clone(),
                        offer:data::OfferEvidence::Held { provider:provider_alias.as_ref().ok_or(NativeAdapterError::Selection)?.clone(), registration:registration.clone() },
                        state:state_data, resources:measurements::resources(usage.usage(),retained)?,
                        source:files.source(snapshot, phase)?,
                        workers:measurements::workers(snapshot.workers(), phase)?,
                        entries:measurements::entries(snapshot),
                    });
                    final_checkpoint = Some(name.clone());
                    if matches!(state, ProductState::Ready) && private_record.is_none() {
                        let id = capture_id.as_ref().ok_or(NativeAdapterError::Selection)?;
                        let observer = record_observer.as_ref().ok_or(NativeAdapterError::ObservationIncomplete)?;
                        let (length, digest) = observer.with_ready_record(id, |raw| (raw.len(),data::ContentSha256::new(Sha256::digest(raw).into())))
                            .map_err(|_| NativeAdapterError::ObservationIncomplete)?;
                        let ticket = observer.with_ready_record(id, |raw| run.prepare_private_record_adoption(raw))
                            .map_err(|_| NativeAdapterError::ObservationIncomplete)?.map_err(|_| NativeAdapterError::ObservationIncomplete)?;
                        let bytes = observer.take(id).map_err(|_| NativeAdapterError::ObservationIncomplete)?
                            .adopt(ticket).map_err(|_| NativeAdapterError::ObservationIncomplete)?;
                        let ready = &ready_reply.as_ref().ok_or(NativeAdapterError::Exchange)?["result"];
                        let declaration = match text(&ready["coverage"],"kind")? {
                            "complete" => data::FrozenDeclaration::Declared {
                                version:data::DeclaredVersion,
                                companions:data::Items::new(ready["companions"].as_array().ok_or(NativeAdapterError::Exchange)?
                                    .iter().map(measurements::declaration_root).collect::<Result<Vec<_>,_>>()?).map_err(data_error)?,
                            },
                            _ => return Err(NativeAdapterError::ObservationIncomplete),
                        };
                        private_record = Some(data::FrozenPrivateRecord { bytes, byte_length:data::ObservedCount(length as u64), sha256:digest,declaration });
                    }
                }
                NativeOriginalAction::Inventory { capture, connection:selected,request_id,start_index,max_entries } => {
                    require_alias(connection.as_ref(),selected)?; require_alias(capture_alias.as_ref(),capture)?;
                    let id = capture_id.as_ref().ok_or(NativeAdapterError::Selection)?;
                    let (reply,frames) = host.request(&deadline,request_id,"morphir.model-originals.inventory",json!({
                        "contractVersion":"0.1.0-draft.1","captureId":id.as_str(),"startIndex":start_index,"maxEntries":max_entries,
                    })).await?;
                    for entry in reply["result"]["entries"].as_array().ok_or(NativeAdapterError::Exchange)? {
                        if entry["kind"] == "file" { entries.insert(text(entry,"path")?.to_owned(), text(entry,"entryId")?.to_owned()); }
                    }
                    transcript.push(frames);
                }
                NativeOriginalAction::ReadSelected { capture,connection:selected,request_id,target,offset,max_bytes } => {
                    require_alias(connection.as_ref(),selected)?; require_alias(capture_alias.as_ref(),capture)?;
                    let NativeReadTarget::OriginalEntry { path } = target else { return Err(NativeAdapterError::UnsupportedAction); };
                    let entry = entries.get(path.as_str()).ok_or(NativeAdapterError::Selection)?;
                    let (reply,frames) = host.request(&deadline,request_id,"morphir.model-originals.read",json!({
                        "contractVersion":"0.1.0-draft.1","captureId":capture_id.as_ref().ok_or(NativeAdapterError::Selection)?.as_str(),
                        "target":{"kind":"original","entryId":entry},"offset":offset,"maxBytes":max_bytes,
                    })).await?;
                    if !reply["result"]["content"].is_string() { return Err(NativeAdapterError::Exchange); }
                    transcript.push(frames);
                }
                NativeOriginalAction::Release { capture,connection:selected,request_id } => {
                    require_alias(connection.as_ref(),selected)?; require_alias(capture_alias.as_ref(),capture)?;
                    let (reply,frames) = host.request(&deadline,request_id,"morphir.model-originals.release",json!({
                        "contractVersion":"0.1.0-draft.1","captureId":capture_id.as_ref().ok_or(NativeAdapterError::Selection)?.as_str(),
                    })).await?;
                    if reply["result"]["status"] != "released" { return Err(NativeAdapterError::Exchange); }
                    transcript.push(frames); state = ProductState::Released;
                }
                NativeOriginalAction::Disconnect { connection:selected } => {
                    require_alias(connection.as_ref(),selected)?;
                    final_snapshot = Some(cleanup(&mut host,&mut prepared,&mut scope,limits.shutdown_grace,capture_work).await?);
                    disposed_transports += 1;
                    state = ProductState::Closed;
                }
                NativeOriginalAction::Unsupported(_) => return Err(NativeAdapterError::UnsupportedAction),
            }
        }
        Ok(())
    }.await;
    if final_snapshot.is_none() {
        let cleaned = cleanup(
            &mut host,
            &mut prepared,
            &mut scope,
            limits.shutdown_grace,
            capture_work,
        )
        .await;
        if cleaned.is_err() {
            return Err(NativeAdapterError::Cleanup);
        }
    }
    result?;
    let final_snapshot = final_snapshot.ok_or(NativeAdapterError::Cleanup)?;
    final_snapshot
        .require_source_complete()
        .map_err(|_| NativeAdapterError::ObservationIncomplete)?;
    let workers = final_snapshot.workers();
    workers
        .require_joined_cleanup()
        .map_err(|_| NativeAdapterError::Cleanup)?;
    let selection = data::ResolvedSelectionData {
        connection: connection.ok_or(NativeAdapterError::Selection)?,
        provider: provider_alias.ok_or(NativeAdapterError::Selection)?,
        project: project_alias.ok_or(NativeAdapterError::Selection)?,
        registration,
        session_id: data::SessionId::new(&session).map_err(|_| NativeAdapterError::Selection)?,
        source: source_data,
        project_id: data::ProjectId::new(&actual_project.ok_or(NativeAdapterError::Selection)?)
            .map_err(|_| NativeAdapterError::Selection)?,
        capture: capture_alias.ok_or(NativeAdapterError::Selection)?,
        capture_id: data::CaptureId::new(
            capture_id
                .as_ref()
                .ok_or(NativeAdapterError::Selection)?
                .as_str(),
        )
        .map_err(|_| NativeAdapterError::Selection)?,
    };
    Ok(NativeOriginalMeasurements {
        profile: data::MeasurementProfile,
        contract_version: data::MeasurementVersion::current().map_err(data_error)?,
        role: data::OriginalRole,
        resolved_selection: selection,
        transcript: data::MeasuredTranscript {
            exchanges: data::Items::new(transcript).map_err(data_error)?,
        },
        captures: data::Items::new(captures).map_err(data_error)?,
        private_record: private_record.ok_or(NativeAdapterError::ObservationIncomplete)?,
        checkpoints: data::Items::new(checkpoints).map_err(data_error)?,
        outcome: data::ScenarioOutcome::Clean {
            final_checkpoint: final_checkpoint.ok_or(NativeAdapterError::ObservationIncomplete)?,
        },
        teardown: data::HarnessTeardown::Confirmed {
            disposed_transports: data::Natural::new(disposed_transports).map_err(data_error)?,
            held_core_results: data::HarnessTeardownConfirmedHeldCoreResults,
            pending_effects: data::HarnessTeardownConfirmedPendingEffects,
            product_release_inferred: data::HarnessTeardownConfirmedProductReleaseInferred,
            still_owned_workers: data::HarnessTeardownConfirmedStillOwnedWorkers,
            workers_exited: data::Natural::new(
                workers.joined_ok() + workers.joined_panicked() + workers.joined_cancelled(),
            )
            .map_err(data_error)?,
            workers_started: data::Natural::new(workers.started()).map_err(data_error)?,
        },
    })
}
fn require_alias(
    actual: Option<&data::FixtureAlias>,
    expected: &data::FixtureAlias,
) -> Result<(), NativeAdapterError> {
    if actual == Some(expected) {
        Ok(())
    } else {
        Err(NativeAdapterError::Selection)
    }
}
async fn cleanup(
    host: &mut RunningHost,
    prepared: &mut Option<PreparedNativeUi>,
    scope: &mut Option<HostSourceObservationScope>,
    grace: std::time::Duration,
    capture_work: CaptureWork,
) -> Result<HostSourceSnapshot, NativeAdapterError> {
    // Interruption ends business work, not cleanup. Genuine join ownership and
    // eventual Arc recovery, rather than counters alone, establish completion.
    let end = tokio::time::Instant::now() + grace;
    let close = host.disconnect(grace).await;
    if let Some(owner) = scope.as_ref() {
        loop {
            let workers = owner.snapshot().workers();
            if matches!(capture_work, CaptureWork::NotRequested)
                || workers.require_joined_cleanup().is_ok()
            {
                break;
            }
            if tokio::time::Instant::now() >= end {
                break;
            }
            tokio::task::yield_now().await;
        }
    }
    let stop = host
        .stop(end.saturating_duration_since(tokio::time::Instant::now()))
        .await;
    drop(prepared.take());
    let mut owner = scope.take().ok_or(NativeAdapterError::Cleanup)?;
    loop {
        match owner.try_seal() {
            Ok(snapshot) => {
                close?;
                stop?;
                if matches!(capture_work, CaptureWork::Requested) {
                    snapshot
                        .workers()
                        .require_joined_cleanup()
                        .map_err(|_| NativeAdapterError::Cleanup)?;
                }
                return Ok(snapshot);
            }
            Err(pending) => {
                owner = pending.into_scope();
                if tokio::time::Instant::now() >= end {
                    return Err(NativeAdapterError::Cleanup);
                }
                tokio::task::yield_now().await;
            }
        }
    }
}
