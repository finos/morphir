//! Confined native filesystem adapter for portable workspace discovery.

mod aliases;
mod capability;
pub use capability::{CapturedWorkspaceDiscovery, WorkspaceDiscoveryRoot};
mod budget;
mod mounts;
mod source_selection;
mod traversal;

pub use source_selection::{
    CapturedSelection, CapturedSource, DEFAULT_SOURCE_BYTES, SourceSelectionOptions,
    capture_source_selection,
};

#[cfg(test)]
mod tests;

use std::{
    collections::BTreeMap,
    error::Error,
    fmt,
    path::{Path, PathBuf},
};

use anyhow::{Context, Result, anyhow};
use cap_std::{ambient_authority, fs::Dir};
use morphir_common::config::MorphirConfig;
use morphir_workspace::{
    DiscoveryFailure, DiscoveryPurpose, DiscoveryRequest, RelativePath, WorkspaceSnapshot,
    discover_with_details,
};

use super::{
    discovery::{native_global_config_candidates, native_system_config_candidates},
    sources::ConfigLoadOptions,
};
use aliases::AliasBudgets;
use budget::NativeReads;
use budget::PayloadBudget;
use mounts::{
    apply_user_override_selection, config_payload_kind, selected_environment, selected_mount,
};
use mounts::{apply_user_override_selection_with_reads, selected_mount_with_reads};
use traversal::{TraversalBudgets, TreeCapturePolicy, build_tree_from_capability};

/// Discover a workspace by adapting a confined native directory to the
/// provider-neutral workspace protocol.
///
/// The granted `root` is canonicalized once and becomes the confinement
/// boundary. Native directories are traversed first, while confined directory
/// symlinks are recorded as aliases. Recognized entries are then copied from
/// the already-built real subtree to each alias without another filesystem
/// traversal. This keeps real paths visible, supports alias-only member globs,
/// and supports nested aliases. Alias edges already present in an expansion's
/// ancestry are skipped, so cycles cannot synthesize deeper paths indefinitely.
/// Fixed budgets bound alias edges, queued and processed expansions, generated
/// entries, and indexing/materialization work. Budget exhaustion returns the
/// stable `workspace.alias.resource-limit` code. Independent fixed budgets cap
/// native directory count, entry count, and depth. One request-wide byte budget
/// covers every retained configuration file across the development tree,
/// materialized alias copies, an explicit user override, Morphir Home, and the
/// system mount. Exhaustion returns the stable
/// `workspace.traversal.resource-limit` code. An unreadable granted entry is an
/// explicit `workspace.traversal.unreadable` error; discovery does not silently
/// skip paths that the merged workspace configuration could name.
///
/// ```no_run
/// use morphir_devkit::{ConfigLoadOptions, discover_workspace};
/// use std::path::Path;
///
/// # fn main() -> anyhow::Result<()> {
/// let snapshot = discover_workspace(Path::new("."), &ConfigLoadOptions::default())?;
/// for project in snapshot.projects {
///     println!("{}: {}", project.relative_path.as_str(), project.name);
/// }
/// # Ok(())
/// # }
/// ```
pub fn discover_workspace(root: &Path, options: &ConfigLoadOptions) -> Result<WorkspaceSnapshot> {
    let request = build_workspace_discovery_request(root, options)?;
    morphir_workspace::discover(request)
        .into_result()
        .map_err(discovery_failure)
}

/// Native discovery output including decoded effective configurations from the
/// exact portable discovery pass and the canonical root bound by the adapter.
#[derive(Debug)]
pub struct NativeWorkspaceDiscovery {
    /// Canonical development root retained as the native confinement boundary.
    pub canonical_root: PathBuf,
    /// Provider-neutral discovery snapshot.
    pub snapshot: WorkspaceSnapshot,
    /// Fully merged root configuration.
    pub root_config: MorphirConfig,
    /// Fully merged configurations for valid projects, keyed by relative path.
    pub project_configs: BTreeMap<RelativePath, MorphirConfig>,
}

/// A typed failure from native workspace discovery.
#[derive(Debug)]
pub enum NativeWorkspaceDiscoveryError {
    /// The provider-neutral discovery engine rejected the request.
    Portable(DiscoveryFailure),
    /// Native filesystem binding or full [`MorphirConfig`] decoding failed.
    Host(anyhow::Error),
}

impl fmt::Display for NativeWorkspaceDiscoveryError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Portable(failure) => {
                let path = failure
                    .path
                    .as_ref()
                    .map(|path| format!(" at `{}`", path.as_str()))
                    .unwrap_or_default();
                write!(formatter, "{}: {}{path}", failure.code, failure.message)
            }
            Self::Host(error) => fmt::Display::fmt(error, formatter),
        }
    }
}

impl Error for NativeWorkspaceDiscoveryError {
    fn source(&self) -> Option<&(dyn Error + 'static)> {
        match self {
            Self::Portable(_) => None,
            Self::Host(error) => Some(error.as_ref()),
        }
    }
}

/// Discover a workspace and decode the exact effective configurations produced
/// by the portable engine without re-reading or re-merging any files.
pub fn discover_workspace_detailed(
    root: &Path,
    options: &ConfigLoadOptions,
) -> Result<NativeWorkspaceDiscovery> {
    discover_workspace_detailed_typed(root, options).map_err(|error| match error {
        NativeWorkspaceDiscoveryError::Portable(failure) => discovery_failure(failure),
        NativeWorkspaceDiscoveryError::Host(error) => error,
    })
}

/// Discover a workspace while preserving the boundary between portable
/// discovery failures and native binding or full-configuration decode errors.
///
/// ```no_run
/// use morphir_devkit::{
///     ConfigLoadOptions, NativeWorkspaceDiscoveryError, discover_workspace_detailed_typed,
/// };
/// use std::path::Path;
///
/// match discover_workspace_detailed_typed(Path::new("."), &ConfigLoadOptions::default()) {
///     Ok(discovery) => println!("{} project(s)", discovery.snapshot.projects.len()),
///     Err(NativeWorkspaceDiscoveryError::Portable(failure)) => {
///         eprintln!("workspace discovery rejected the request: {}", failure.code);
///     }
///     Err(NativeWorkspaceDiscoveryError::Host(error)) => {
///         eprintln!("native workspace discovery failed: {error}");
///     }
/// }
/// ```
pub fn discover_workspace_detailed_typed(
    root: &Path,
    options: &ConfigLoadOptions,
) -> std::result::Result<NativeWorkspaceDiscovery, NativeWorkspaceDiscoveryError> {
    let (canonical_root, request) = bind_workspace_discovery_request(root, options)
        .map_err(NativeWorkspaceDiscoveryError::Host)?;
    decode_captured_details(canonical_root, request)
}

fn decode_captured_details(
    canonical_root: PathBuf,
    request: DiscoveryRequest,
) -> std::result::Result<NativeWorkspaceDiscovery, NativeWorkspaceDiscoveryError> {
    let details =
        discover_with_details(request).map_err(NativeWorkspaceDiscoveryError::Portable)?;
    let root_config = decode_effective_config(details.root_effective)
        .context("Failed to decode effective root Morphir configuration")
        .map_err(NativeWorkspaceDiscoveryError::Host)?;
    let project_configs = details
        .project_effective
        .into_iter()
        .map(|(path, value)| {
            if path == RelativePath::root() {
                Ok((path, root_config.clone()))
            } else {
                decode_effective_config(value)
                    .with_context(|| {
                        format!(
                            "Failed to decode effective Morphir configuration for `{}`",
                            path.as_str()
                        )
                    })
                    .map(|config| (path, config))
            }
        })
        .collect::<Result<_>>()
        .map_err(NativeWorkspaceDiscoveryError::Host)?;
    Ok(NativeWorkspaceDiscovery {
        canonical_root,
        snapshot: details.snapshot,
        root_config,
        project_configs,
    })
}

fn decode_effective_config(mut value: serde_json::Value) -> Result<MorphirConfig> {
    if let Some(project) = value
        .get_mut("project")
        .and_then(serde_json::Value::as_object_mut)
    {
        project
            .entry("version")
            .or_insert_with(|| serde_json::Value::String(String::new()));
    }
    serde_json::from_value(value).map_err(Into::into)
}

/// Build the provider-neutral request used by [`discover_workspace`].
///
/// This lower-level API is useful to native hosts that need to serialize or
/// compare the exact request before running the pure discovery engine.
pub fn build_workspace_discovery_request(
    root: &Path,
    options: &ConfigLoadOptions,
) -> Result<DiscoveryRequest> {
    bind_workspace_discovery_request(root, options).map(|(_, request)| request)
}

fn bind_workspace_discovery_request(
    root: &Path,
    options: &ConfigLoadOptions,
) -> Result<(PathBuf, DiscoveryRequest)> {
    bind_workspace_discovery_request_with_hook(root, options, &mut |_| {})
}

fn bind_workspace_discovery_request_with_hook(
    root: &Path,
    options: &ConfigLoadOptions,
    root_opened_hook: &mut dyn FnMut(&Path),
) -> Result<(PathBuf, DiscoveryRequest)> {
    bind_workspace_discovery_request_with(
        root,
        options,
        AliasBudgets::DEFAULT,
        TraversalBudgets::DEFAULT,
        root_opened_hook,
    )
}

#[cfg(test)]
fn bind_workspace_discovery_request_with_budgets(
    root: &Path,
    options: &ConfigLoadOptions,
    alias_budgets: AliasBudgets,
    traversal_budgets: TraversalBudgets,
) -> Result<(PathBuf, DiscoveryRequest)> {
    bind_workspace_discovery_request_with(
        root,
        options,
        alias_budgets,
        traversal_budgets,
        &mut |_| {},
    )
}

fn bind_workspace_discovery_request_with(
    root: &Path,
    options: &ConfigLoadOptions,
    alias_budgets: AliasBudgets,
    traversal_budgets: TraversalBudgets,
    root_opened_hook: &mut dyn FnMut(&Path),
) -> Result<(PathBuf, DiscoveryRequest)> {
    let granted_root = if root.is_absolute() {
        root.to_path_buf()
    } else {
        std::env::current_dir()
            .context("Failed to resolve relative development root")?
            .join(root)
    };
    let root_capability =
        Dir::open_ambient_dir(&granted_root, ambient_authority()).with_context(|| {
            format!(
                "Failed to open development root: {}",
                granted_root.display()
            )
        })?;
    root_opened_hook(&granted_root);
    WorkspaceDiscoveryRoot::from_directory(root_capability, &granted_root)?
        .capture_with_budgets(options, alias_budgets, traversal_budgets)
        .map(CapturedWorkspaceDiscovery::into_parts)
}

fn capture_request(
    root_capability: &Dir,
    canonical_root: &Path,
    granted_root: &Path,
    options: &ConfigLoadOptions,
    alias_budgets: AliasBudgets,
    traversal_budgets: TraversalBudgets,
) -> Result<DiscoveryRequest> {
    capture_request_with_reads(
        root_capability,
        canonical_root,
        granted_root,
        options,
        alias_budgets,
        traversal_budgets,
        None,
    )
}

fn capture_request_with_reads(
    root_capability: &Dir,
    canonical_root: &Path,
    granted_root: &Path,
    options: &ConfigLoadOptions,
    alias_budgets: AliasBudgets,
    traversal_budgets: TraversalBudgets,
    scope: Option<&morphir_common::config::observation::SourceReadScope>,
) -> Result<DiscoveryRequest> {
    let mut payload = PayloadBudget::new(traversal_budgets.config_bytes);
    let reads = match scope {
        Some(scope) => NativeReads::Observed(scope),
        None => NativeReads::Unobserved,
    };
    let classify_config = |path: &RelativePath| config_payload_kind(&options.user_override, path);
    let mut development_root = build_tree_from_capability(
        root_capability,
        canonical_root,
        granted_root,
        TreeCapturePolicy {
            aliases: alias_budgets,
            traversal: traversal_budgets,
        },
        &mut payload,
        &classify_config,
        reads,
    )?;
    match reads {
        NativeReads::Unobserved => apply_user_override_selection(
            &mut development_root,
            &options.user_override,
            &mut payload,
        )?,
        NativeReads::Observed(_) => apply_user_override_selection_with_reads(
            &mut development_root,
            &options.user_override,
            &mut payload,
            reads,
        )?,
    }

    let request = DiscoveryRequest {
        protocol_version: morphir_workspace::workspace_discovery_protocol(),
        development_root,
        morphir_home: match reads {
            NativeReads::Unobserved => selected_mount(
                &options.global,
                native_global_config_candidates,
                "global user",
                &mut payload,
            )?,
            NativeReads::Observed(_) => selected_mount_with_reads(
                &options.global,
                native_global_config_candidates,
                "global user",
                &mut payload,
                reads,
            )?,
        },
        system_config: match reads {
            NativeReads::Unobserved => selected_mount(
                &options.system,
                || native_system_config_candidates().to_vec(),
                "system",
                &mut payload,
            )?,
            NativeReads::Observed(_) => selected_mount_with_reads(
                &options.system,
                || native_system_config_candidates().to_vec(),
                "system",
                &mut payload,
                reads,
            )?,
        },
        environment: selected_environment(options),
        cli_overlay: serde_json::json!({}),
        purpose: DiscoveryPurpose::default(),
    };
    Ok(request)
}

fn discovery_failure(failure: morphir_workspace::DiscoveryFailure) -> anyhow::Error {
    let path = failure
        .path
        .as_ref()
        .map(|path| format!(" at `{}`", path.as_str()))
        .unwrap_or_default();
    anyhow!("{}: {}{path}", failure.code, failure.message)
}
