//! Compile-only check of the unchanged maintained private identity module.
//! This is not a whole-crate or native Windows runtime qualification.
pub mod config {
    pub mod observation {
        mod identity;

        pub fn compare(file: std::fs::File, path: &std::path::Path) -> std::io::Result<bool> {
            Ok(identity::FileIdentity::from_file(file)? == identity::FileIdentity::from_path(path)?)
        }
    }
}
