#[test]
fn actual_selected_root_open_is_complete_with_exact_business_and_witness_counts() {
    let root = tempfile::tempdir().unwrap();
    std::fs::write(
        root.path().join("model.json"),
        include_bytes!("source_observation_fixtures/primary.json"),
    )
    .unwrap();
    let root_dir = held(root.path());
    let scope = SourceReadScope::bind_workspace(
        &root_dir,
        root.path(),
        ReadLimits::new(64, 1024, 16_777_216, 16).unwrap(),
    )
    .unwrap();
    let witness = scope
        .register_file(&root_dir, Path::new("model.json"))
        .unwrap();
    let directory = scope.content_directory(&root_dir, Some(root.path()));
    let mut file = directory
        .open_content_file(Path::new("model.json"), &options())
        .unwrap();
    assert!(file.metadata().unwrap().is_file());
    assert_eq!(file.metadata().unwrap().len(), 111);
    let before = scope.observation().snapshot();
    assert_eq!(before.total_counts().content_attempts(), 1);
    assert_eq!(before.total_counts().read_calls(), 0);
    assert_eq!(before.total_counts().returned_bytes(), 0);
    assert_eq!(before.coverage(), Coverage::Partial);
    let mut block = [0u8; 65_536];
    let mut bytes = Vec::new();
    loop {
        let count = file.read(&mut block).unwrap();
        if count == 0 {
            break;
        }
        bytes.extend_from_slice(&block[..count]);
    }
    assert_eq!(
        bytes,
        include_bytes!("source_observation_fixtures/primary.json")
    );
    drop(file);
    drop(directory);
    let snapshot = scope.seal();
    assert_eq!(snapshot.coverage(), Coverage::Complete);
    snapshot.require_complete().unwrap();
    let total = snapshot.total_counts();
    assert_eq!(total.content_attempts(), 1);
    assert_eq!(total.read_calls(), 2);
    assert_eq!(total.returned_bytes(), 111);
    let file_counts = snapshot.counts_for(&witness).unwrap();
    assert_eq!(file_counts.content_attempts(), 1);
    assert_eq!(file_counts.read_calls(), 2);
    assert_eq!(file_counts.returned_bytes(), 111);
    let workspace = snapshot.counts(ReadClass::WorkspaceContent);
    assert_eq!(workspace.content_attempts(), 1);
    assert_eq!(workspace.read_calls(), 2);
    assert_eq!(workspace.returned_bytes(), 111);
    let ambient = snapshot.counts(ReadClass::AmbientContent);
    assert_eq!(ambient.content_attempts(), 0);
    assert_eq!(ambient.read_calls(), 0);
    assert_eq!(ambient.returned_bytes(), 0);
}
