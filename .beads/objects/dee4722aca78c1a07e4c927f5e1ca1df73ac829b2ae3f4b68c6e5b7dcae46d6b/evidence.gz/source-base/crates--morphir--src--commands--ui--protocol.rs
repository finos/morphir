//! Versioned wire types shared by the loopback web host and Morphir Web.

use std::collections::BTreeSet;

use serde::{Deserialize, Serialize};
use serde_json::Value;

use crate::error::CliError;

/// The connected protocol version the CLI both serves and accepts.
///
/// This is pinned to the vendored client in
/// `crates/morphir/src/commands/ui/assets/`, which validates the session
/// manifest against a literal version of its own. Serving a version that
/// bundle does not pin breaks every session, `morphir ui` included, because
/// the client rejects the manifest before it ever opens the socket.
///
/// The playground methods did not need a bump: they are purely additive, and
/// a client that has never heard of `morphir.playground.catalog` never calls
/// it. Bumping the version is the one thing that does break an older client,
/// and it buys nothing until a playground-capable bundle exists. Bump this
/// only in the same change that vendors a client bundle pinning the new
/// version — the guard test in [`super::assets`] fails otherwise.
pub const CONNECTED_PROTOCOL_VERSION: u32 = 1;

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub enum ConnectedMethod {
    #[serde(rename = "morphir.session.initialize")]
    Initialize,
    #[serde(rename = "morphir.development.inspect")]
    DevelopmentInspect,
    #[serde(rename = "morphir.project-model.open")]
    ProjectModelOpen,
    #[serde(rename = "morphir.workspace.open")]
    WorkspaceOpen,
    #[serde(rename = "morphir.workspace.watch")]
    WorkspaceWatch,
    #[serde(rename = "morphir.workspace.unwatch")]
    WorkspaceUnwatch,
    #[serde(rename = "morphir.playground.catalog")]
    PlaygroundCatalog,
    #[serde(rename = "morphir.playground.compile")]
    PlaygroundCompile,
    #[serde(rename = "morphir.playground.generate")]
    PlaygroundGenerate,
    #[serde(rename = "morphir.artifacts.generate")]
    ArtifactsGenerate,
    #[serde(rename = "morphir.artifacts.read")]
    ArtifactsRead,
    #[serde(rename = "morphir.artifacts.release")]
    ArtifactsRelease,
    #[serde(rename = "morphir.model-originals.capture")]
    ModelOriginalsCapture,
    #[serde(rename = "morphir.model-originals.inventory")]
    ModelOriginalsInventory,
    #[serde(rename = "morphir.model-originals.read")]
    ModelOriginalsRead,
    #[serde(rename = "morphir.model-originals.release")]
    ModelOriginalsRelease,
}

impl ConnectedMethod {
    pub fn is_model_originals(self) -> bool {
        matches!(
            self,
            Self::ModelOriginalsCapture
                | Self::ModelOriginalsInventory
                | Self::ModelOriginalsRead
                | Self::ModelOriginalsRelease
        )
    }

    pub fn is_artifact_transfer(self) -> bool {
        matches!(
            self,
            Self::ArtifactsGenerate | Self::ArtifactsRead | Self::ArtifactsRelease
        )
    }
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct JsonRpcRequest {
    pub jsonrpc: JsonRpcVersion,
    pub id: u64,
    pub method: ConnectedMethod,
    pub params: Value,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub enum JsonRpcVersion {
    #[serde(rename = "2.0")]
    V2,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct WorkbenchSourceRef {
    pub provider_id: String,
    pub locator: String,
    pub display_name: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub persistence: Option<SourcePersistence>,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "kebab-case")]
pub enum SourcePersistence {
    Session,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct WorkbenchCapability {
    pub name: String,
    pub version: String,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ProviderProvenance {
    pub extension_id: String,
    pub extension_version: String,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ProviderManifest {
    pub id: String,
    pub name: String,
    pub kind: ProviderKind,
    pub status: ProviderStatus,
    pub capabilities: Vec<WorkbenchCapability>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub provenance: Option<ProviderProvenance>,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "kebab-case")]
pub enum ProviderKind {
    Connected,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "kebab-case")]
pub enum ProviderStatus {
    Available,
    Disconnected,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct SessionManifest {
    pub protocol_version: u32,
    pub web_socket_path: String,
    pub session_id: String,
    pub providers: Vec<ProviderManifest>,
    pub initial_sources: Vec<WorkbenchSourceRef>,
}

impl SessionManifest {
    pub fn validate(self) -> Result<Self, CliError> {
        if self.protocol_version != CONNECTED_PROTOCOL_VERSION {
            return Err(protocol_error(format!(
                "Unsupported connected protocol version {}",
                self.protocol_version
            )));
        }
        if self.web_socket_path != "/rpc" {
            return Err(protocol_error("The connected WebSocket path must be /rpc"));
        }
        let provider_ids = self
            .providers
            .iter()
            .map(|provider| provider.id.as_str())
            .collect::<BTreeSet<_>>();
        if provider_ids.len() != self.providers.len() {
            return Err(protocol_error(
                "Connected session provider IDs must be unique",
            ));
        }
        if self
            .initial_sources
            .iter()
            .any(|source| !provider_ids.contains(source.provider_id.as_str()))
        {
            return Err(protocol_error(
                "Connected session initial sources must reference an advertised provider",
            ));
        }
        Ok(self)
    }
}

#[derive(Default)]
pub struct RequestLedger {
    seen: BTreeSet<u64>,
}

impl RequestLedger {
    pub fn register(&mut self, id: u64) -> Result<(), CliError> {
        if self.seen.insert(id) {
            Ok(())
        } else {
            Err(protocol_error(format!(
                "JSON-RPC request ID {id} was already used"
            )))
        }
    }
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct DevelopmentWorkbenchDescriptor {
    pub id: String,
    pub source: WorkbenchSourceRef,
    pub name: String,
    pub kind: DevelopmentWorkbenchKind,
    pub route: DevelopmentWorkbenchRoute,
    pub opened_at: String,
    pub last_used_at: String,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "kebab-case")]
pub enum DevelopmentWorkbenchKind {
    Development,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "kebab-case")]
pub enum DevelopmentWorkbenchRoute {
    Overview,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct InspectResult {
    pub descriptor: DevelopmentWorkbenchDescriptor,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ProjectModelOpenParams {
    pub source: WorkbenchSourceRef,
    pub project_id: String,
}

impl ProjectModelOpenParams {
    pub fn validate(self) -> Result<Self, CliError> {
        if self.project_id.is_empty() {
            Err(protocol_error("Project ID must not be empty"))
        } else {
            Ok(self)
        }
    }
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ModelWorkbenchDescriptor {
    pub id: String,
    pub source: WorkbenchSourceRef,
    pub name: String,
    pub kind: ModelWorkbenchKind,
    pub distribution: ModelWorkbenchDistribution,
    pub route: ModelWorkbenchRoute,
    pub opened_at: String,
    pub last_used_at: String,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "kebab-case")]
pub enum ModelWorkbenchKind {
    Model,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "kebab-case")]
pub enum ModelWorkbenchDistribution {
    SingleFile,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "kebab-case")]
pub enum ModelWorkbenchRoute {
    Explorer,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ProjectModelOpenResult {
    pub descriptor: ModelWorkbenchDescriptor,
    pub content: String,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct WorkspaceSnapshot {
    pub id: String,
    pub root: WorkbenchSourceRef,
    pub name: Option<String>,
    pub config_anchor: Option<String>,
    pub state: WorkspaceState,
    pub projects: Vec<ProjectSnapshot>,
    pub model_sources: Vec<WorkbenchSourceRef>,
    pub knowledge_base_sources: Vec<WorkbenchSourceRef>,
    pub diagnostics: Vec<WorkspaceDiagnostic>,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "kebab-case")]
pub enum WorkspaceState {
    Open,
    Error,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ProjectSnapshot {
    pub id: String,
    pub name: String,
    pub version: Option<String>,
    pub relative_path: String,
    pub config_anchor: Option<String>,
    pub source_directory: String,
    pub state: ProjectState,
    pub model_sources: Vec<WorkbenchSourceRef>,
    pub knowledge_base_sources: Vec<WorkbenchSourceRef>,
    pub diagnostics: Vec<WorkspaceDiagnostic>,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "kebab-case")]
pub enum ProjectState {
    Unloaded,
    Error,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct WorkspaceDiagnostic {
    pub severity: DiagnosticSeverity,
    pub code: Option<String>,
    pub message: String,
    pub path: Option<String>,
    pub project_id: Option<String>,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "kebab-case")]
pub enum DiagnosticSeverity {
    Info,
    Warning,
    Error,
}

/// Where the `/launch` redirect should land. Not a protocol field: morphir-ui
/// has real URL routing, so the URL is the single source of truth for which
/// view is open, and a parallel manifest field would be a second mechanism
/// for the same thing.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum InitialView {
    Playground,
}

impl InitialView {
    /// The in-app hash this view is addressed by.
    pub fn hash(self) -> &'static str {
        match self {
            Self::Playground => "#/playground",
        }
    }
}

/// Parameters for `morphir.playground.compile`.
///
/// Mirrors `morphir_extension_sdk::CompileRequest` minus `dependencies`: the
/// playground compiles a single in-memory package with no dependency
/// distributions, and the provider adds an empty dependency list when it
/// builds the real MEP request. The protocol layer owns this shape
/// separately from the SDK type so an SDK change cannot silently change the
/// browser-facing contract.
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct PlaygroundCompileParams {
    pub language_id: String,
    pub documents: Vec<PlaygroundSourceDocument>,
    pub package: PlaygroundPackage,
    pub ir_version: String,
    pub options: Value,
}

#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct PlaygroundSourceDocument {
    pub uri: String,
    pub language_id: String,
    pub version: u64,
    pub text: String,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct PlaygroundPackage {
    pub name: String,
    /// Omitted exposes all modules; an explicit empty list exposes none.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub exposed_modules: Option<Vec<String>>,
}

/// Result of `morphir.playground.compile`. Omits `deny_unknown_fields` (unlike
/// the params types) so a future server field does not break an older client
/// mid-session.
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PlaygroundCompileResult {
    pub success: bool,
    pub ir_version: Option<String>,
    pub ir: Option<Value>,
    pub diagnostics: Vec<PlaygroundDiagnostic>,
    pub modules: Vec<String>,
}

/// Parameters for `morphir.playground.generate`.
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct PlaygroundGenerateParams {
    pub ir: Value,
    pub ir_version: String,
    pub target: String,
    pub options: Value,
}

/// Result of `morphir.playground.generate`. Omits `deny_unknown_fields` for
/// the same forward-compatibility reason as [`PlaygroundCompileResult`].
#[derive(Clone, Debug, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PlaygroundGenerateResult {
    pub success: bool,
    pub artifacts: Vec<PlaygroundArtifact>,
    pub diagnostics: Vec<PlaygroundDiagnostic>,
}

/// A generated artifact held in memory. `path` is a relative hint for
/// display and download naming, not a filesystem location: nothing is
/// written to disk.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct PlaygroundArtifact {
    pub path: String,
    pub content: String,
    pub binary: bool,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct PlaygroundDiagnostic {
    pub severity: String,
    pub code: Option<String>,
    pub message: String,
    pub location: Option<PlaygroundLocation>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct PlaygroundLocation {
    pub uri: String,
    pub range: PlaygroundRange,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct PlaygroundRange {
    pub start: PlaygroundPosition,
    pub end: PlaygroundPosition,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct PlaygroundPosition {
    pub line: u32,
    pub character: u32,
}

/// What one Morphir UI session can compile and generate.
///
/// A projection of the CLI's extension registry, not a second source of
/// truth: the registry decides which provider serves a language or target,
/// and this only reports what it decided so the browser can populate its
/// pickers. The browser never names a provider when it compiles — it names a
/// language and an IR version, and the host resolves those the same way
/// `morphir compile` does.
#[derive(Clone, Debug, Default, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PlaygroundCatalog {
    pub frontends: Vec<PlaygroundFrontend>,
    pub targets: Vec<PlaygroundTarget>,
}

impl PlaygroundCatalog {
    /// Look up the first frontend entry offering `language_id`.
    pub fn frontend(&self, language_id: &str) -> Option<&PlaygroundFrontend> {
        self.frontends
            .iter()
            .find(|frontend| frontend.language_id == language_id)
    }

    /// Look up the first target entry named `target`.
    pub fn target(&self, target: &str) -> Option<&PlaygroundTarget> {
        self.targets.iter().find(|entry| entry.target == target)
    }
}

/// One source language the session can compile.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PlaygroundFrontend {
    pub language_id: String,
    pub display_name: String,
    /// The extensions this language's files usually carry, for the editor's
    /// language picker. Advisory: the playground compiles in-memory buffers,
    /// which have no filenames.
    pub file_extensions: Vec<String>,
    pub ir_versions: Vec<String>,
    pub compile: bool,
    /// Whether the provider supports incremental compilation, or `null` when
    /// the session cannot tell.
    ///
    /// An installed provider's capability metadata is rebuilt from what its
    /// install persisted, and the persisted record carries only the
    /// languages, IR versions and the compile flag. Reporting `false` there
    /// would claim the extension refuses a capability it may well have, and a
    /// picker cannot distinguish a refusal from an absence of information. The
    /// key is always present so a client can decode it as a nullable boolean.
    pub incremental: Option<bool>,
    /// Whether the provider supports compiling source fragments, or `null`
    /// when the session cannot tell. See [`Self::incremental`].
    pub fragments: Option<bool>,
    pub provider: PlaygroundProviderRef,
}

/// One target the session can generate.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PlaygroundTarget {
    pub target: String,
    pub display_name: String,
    pub ir_versions: Vec<String>,
    pub generate: bool,
    pub provider: PlaygroundProviderRef,
}

/// The extension behind a catalog entry, for display and support reports.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PlaygroundProviderRef {
    pub extension_id: String,
    pub extension_name: String,
    pub version: String,
    pub origin: PlaygroundProviderOrigin,
    /// How the host would invoke this provider, as the registry's own name
    /// for it. Reported so a bug report can say which transport ran.
    pub invocation_mode: String,
}

/// Where a catalog entry's provider came from.
#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "kebab-case")]
pub enum PlaygroundProviderOrigin {
    /// Linked into the CLI itself.
    Builtin,
    /// Installed through the verified extension pipeline.
    Installed,
}

pub fn source_key(source: &WorkbenchSourceRef) -> String {
    serde_json::to_string(&[source.provider_id.as_str(), source.locator.as_str()])
        .expect("source keys contain only strings")
}

pub fn project_key(root: &WorkbenchSourceRef, relative_path: &str) -> String {
    serde_json::to_string(&[
        root.provider_id.as_str(),
        root.locator.as_str(),
        relative_path,
    ])
    .expect("project keys contain only strings")
}

pub(crate) fn protocol_error(message: impl Into<String>) -> CliError {
    CliError::Validation {
        message: message.into(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn manifest() -> SessionManifest {
        SessionManifest {
            protocol_version: CONNECTED_PROTOCOL_VERSION,
            web_socket_path: "/rpc".into(),
            session_id: "session-1".into(),
            providers: vec![ProviderManifest {
                id: "cli:session-1".into(),
                name: "Morphir CLI".into(),
                kind: ProviderKind::Connected,
                status: ProviderStatus::Available,
                capabilities: vec![],
                provenance: None,
            }],
            initial_sources: vec![WorkbenchSourceRef {
                provider_id: "cli:session-1".into(),
                locator: "workspace:initial".into(),
                display_name: "orders".into(),
                persistence: None,
            }],
        }
    }

    #[test]
    fn session_manifest_round_trips_and_enforces_references() {
        let encoded = serde_json::to_string(&manifest()).unwrap();
        let decoded = serde_json::from_str::<SessionManifest>(&encoded)
            .unwrap()
            .validate()
            .unwrap();
        assert_eq!(decoded, manifest());

        let mut duplicate = manifest();
        duplicate.providers.push(duplicate.providers[0].clone());
        assert!(duplicate.validate().is_err());

        let mut foreign = manifest();
        foreign.initial_sources[0].provider_id = "cli:other".into();
        assert!(foreign.validate().is_err());
    }

    #[test]
    fn rejects_unknown_methods_and_protocol_versions() {
        assert!(
            serde_json::from_value::<JsonRpcRequest>(serde_json::json!({
                "jsonrpc": "2.0",
                "id": 1,
                "method": "morphir.filesystem.read",
                "params": {}
            }))
            .is_err()
        );
        let mut incompatible = manifest();
        incompatible.protocol_version = CONNECTED_PROTOCOL_VERSION + 1;
        assert!(incompatible.validate().is_err());
    }

    #[test]
    fn project_model_open_uses_strict_camel_case_parameters() {
        let request = serde_json::from_value::<JsonRpcRequest>(serde_json::json!({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "morphir.project-model.open",
            "params": {
                "source": {
                    "providerId": "cli:session-1",
                    "locator": "workspace:initial",
                    "displayName": "orders"
                },
                "projectId": "project-1"
            }
        }))
        .unwrap();
        assert_eq!(request.method, ConnectedMethod::ProjectModelOpen);
        let params = serde_json::from_value::<ProjectModelOpenParams>(request.params).unwrap();
        assert_eq!(params.project_id, "project-1");

        assert!(
            serde_json::from_value::<ProjectModelOpenParams>(serde_json::json!({
                "source": params.source,
                "projectId": "project-1",
                "path": "/private/workspace/morphir-ir.json"
            }))
            .is_err()
        );
        assert!(
            serde_json::from_value::<ProjectModelOpenParams>(serde_json::json!({
                "source": params.source,
                "projectId": ""
            }))
            .unwrap()
            .validate()
            .is_err()
        );
    }

    #[test]
    fn request_ids_cannot_be_reused() {
        let mut ledger = RequestLedger::default();
        ledger.register(7).unwrap();
        assert!(ledger.register(7).is_err());
    }

    #[test]
    fn playground_methods_use_their_wire_names() {
        for (method, wire) in [
            (
                ConnectedMethod::PlaygroundCatalog,
                "morphir.playground.catalog",
            ),
            (
                ConnectedMethod::PlaygroundCompile,
                "morphir.playground.compile",
            ),
            (
                ConnectedMethod::PlaygroundGenerate,
                "morphir.playground.generate",
            ),
        ] {
            assert_eq!(
                serde_json::to_value(method).unwrap(),
                serde_json::json!(wire)
            );
            assert_eq!(
                serde_json::from_value::<ConnectedMethod>(serde_json::json!(wire)).unwrap(),
                method
            );
        }
    }

    #[test]
    fn compile_params_round_trip_in_camel_case() {
        let params = PlaygroundCompileParams {
            language_id: "elm".into(),
            documents: vec![PlaygroundSourceDocument {
                uri: "morphir-playground:/Main.elm".into(),
                language_id: "elm".into(),
                version: 1,
                text: "module Main exposing (..)".into(),
            }],
            package: PlaygroundPackage {
                name: "local/main".into(),
                exposed_modules: Some(vec!["Main".into()]),
            },
            ir_version: "3".into(),
            options: serde_json::json!({}),
        };

        let value = serde_json::to_value(&params).unwrap();

        assert_eq!(value["languageId"], "elm");
        assert_eq!(value["documents"][0]["languageId"], "elm");
        assert_eq!(value["package"]["exposedModules"][0], "Main");
        assert_eq!(value["irVersion"], "3");
        let decoded: PlaygroundCompileParams = serde_json::from_value(value).unwrap();
        assert_eq!(decoded.package.name, "local/main");
    }

    #[test]
    fn generate_results_carry_artifacts_without_a_path_on_disk() {
        let result = PlaygroundGenerateResult {
            success: true,
            artifacts: vec![PlaygroundArtifact {
                path: "nested/schema.avsc".into(),
                content: "{}".into(),
                binary: false,
            }],
            diagnostics: vec![],
        };

        let value = serde_json::to_value(&result).unwrap();

        assert_eq!(value["artifacts"][0]["path"], "nested/schema.avsc");
        assert_eq!(value["artifacts"][0]["content"], "{}");
        assert_eq!(value["artifacts"][0]["binary"], false);
        assert!(
            value.get("outputPath").is_none(),
            "artifacts must not reference a filesystem path"
        );
    }

    #[test]
    fn the_protocol_version_is_one() {
        assert_eq!(CONNECTED_PROTOCOL_VERSION, 1);
    }

    #[test]
    fn a_diagnostic_location_uses_zero_based_positions() {
        let json = serde_json::json!({
            "severity": "error",
            "message": "Type mismatch",
            "location": {
                "uri": "morphir-playground:/Main.elm",
                "range": {"start": {"line": 0, "character": 4}, "end": {"line": 0, "character": 9}}
            }
        });

        let diagnostic: PlaygroundDiagnostic = serde_json::from_value(json).unwrap();

        let location = diagnostic.location.unwrap();
        assert_eq!(location.range.start.line, 0);
        assert_eq!(location.range.end.character, 9);
    }
}
